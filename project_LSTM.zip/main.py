import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, accuracy_score, recall_score
import joblib

# 定义 Sigmoid 激活函数
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# 定义 Tanh 激活函数
def tanh(x):
    return np.tanh(x)

# 定义 Sigmoid 函数的导数
def sigmoid_derivative(x):
    return sigmoid(x) * (1 - sigmoid(x))

# 定义 Tanh 函数的导数
def tanh_derivative(x):
    return 1 - np.tanh(x) ** 2

class LSTM:
    def __init__(self, input_size, hidden_size, num_layers=2, dropout_rate=0.2, l2_reg=0.01):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.dropout_rate = dropout_rate
        self.l2_reg = l2_reg
        self.layers = []
        for i in range(num_layers):
            if i == 0:
                layer_input_size = input_size
            else:
                layer_input_size = hidden_size
            layer = {
                "Wf": np.random.randn(hidden_size, layer_input_size + hidden_size) * 0.01,
                "bf": np.zeros((hidden_size, 1)),
                "Wi": np.random.randn(hidden_size, layer_input_size + hidden_size) * 0.01,
                "bi": np.zeros((hidden_size, 1)),
                "Wo": np.random.randn(hidden_size, layer_input_size + hidden_size) * 0.01,
                "bo": np.zeros((hidden_size, 1)),
                "Wc": np.random.randn(hidden_size, layer_input_size + hidden_size) * 0.01,
                "bc": np.zeros((hidden_size, 1)),
                "Wh": np.random.randn(1, hidden_size) * 0.01,
                "bh": np.zeros((1, 1))
            }
            self.layers.append(layer)

    def forward(self, inputs):
        all_h_lists = []
        all_c_lists = []
        for layer in self.layers:
            h_prev = np.zeros((self.hidden_size, 1))
            c_prev = np.zeros((self.hidden_size, 1))
            h_list = []
            c_list = []
            for input_t in inputs:
                input_t = input_t.reshape(-1, 1)
                combined = np.vstack((h_prev, input_t))
                # 遗忘门
                ft = sigmoid(np.dot(layer["Wf"], combined) + layer["bf"])
                # 输入门
                it = sigmoid(np.dot(layer["Wi"], combined) + layer["bi"])
                Ct_tilde = tanh(np.dot(layer["Wc"], combined) + layer["bc"])
                # 细胞状态更新
                ct = ft * c_prev + it * Ct_tilde
                # 输出门
                ot = sigmoid(np.dot(layer["Wo"], combined) + layer["bo"])
                ht = ot * tanh(ct)
                h_prev = ht
                c_prev = ct
                h_list.append(ht)
                c_list.append(ct)
            all_h_lists.append(h_list)
            all_c_lists.append(c_list)
            inputs = h_list  # 将当前层的输出作为下一层的输入
        # 输出层
        outputs = []
        last_h_list = all_h_lists[-1]
        last_layer = self.layers[-1]
        for ht in last_h_list:
            output = np.dot(last_layer["Wh"], ht) + last_layer["bh"]
            outputs.append(output)
        return outputs, all_h_lists, all_c_lists

    def backward(self, inputs, target, all_h_lists, all_c_lists):
        num_layers = len(self.layers)
        num_steps = len(inputs)
        dh_next = np.zeros((self.hidden_size, 1))
        dc_next = np.zeros((self.hidden_size, 1))
        layer_grads = [{"Wf": np.zeros_like(layer["Wf"]), "bf": np.zeros_like(layer["bf"]),
                        "Wi": np.zeros_like(layer["Wi"]), "bi": np.zeros_like(layer["bi"]),
                        "Wo": np.zeros_like(layer["Wo"]), "bo": np.zeros_like(layer["bo"]),
                        "Wc": np.zeros_like(layer["Wc"]), "bc": np.zeros_like(layer["bc"]),
                        "Wh": np.zeros_like(layer["Wh"]), "bh": np.zeros_like(layer["bh"])} for layer in self.layers]

        # 计算输出层的梯度
        last_layer = self.layers[-1]
        h_t = all_h_lists[-1][-1]
        output = np.dot(last_layer["Wh"], h_t) + last_layer["bh"]
        doutput = 2 * (output - target)
        dWh = np.dot(doutput, h_t.T)
        dbh = doutput
        dh = np.dot(last_layer["Wh"].T, doutput) + dh_next
        layer_grads[-1]["Wh"] += dWh
        layer_grads[-1]["bh"] += dbh

        for t in reversed(range(num_steps)):
            for layer_idx in reversed(range(num_layers)):
                layer = self.layers[layer_idx]
                h_prev = np.zeros((self.hidden_size, 1)) if t == 0 else all_h_lists[layer_idx][t - 1]
                c_prev = np.zeros((self.hidden_size, 1)) if t == 0 else all_c_lists[layer_idx][t - 1]
                c_t = all_c_lists[layer_idx][t]
                input_t = inputs[t] if layer_idx == 0 else all_h_lists[layer_idx - 1][t]
                input_t = input_t.reshape(-1, 1)
                combined = np.vstack((h_prev, input_t))

                ft = sigmoid(np.dot(layer["Wf"], combined) + layer["bf"])
                it = sigmoid(np.dot(layer["Wi"], combined) + layer["bi"])
                Ct_tilde = tanh(np.dot(layer["Wc"], combined) + layer["bc"])
                ot = sigmoid(np.dot(layer["Wo"], combined) + layer["bo"])

                dc = dh * ot * tanh_derivative(c_t) + dc_next
                dCt_tilde = dc * it
                dit = dc * Ct_tilde
                dft = dc * c_prev
                dot = dh * tanh(c_t)

                dWf = np.dot(dft * sigmoid_derivative(np.dot(layer["Wf"], combined) + layer["bf"]), combined.T)
                dbf = dft * sigmoid_derivative(np.dot(layer["Wf"], combined) + layer["bf"])
                dWi = np.dot(dit * sigmoid_derivative(np.dot(layer["Wi"], combined) + layer["bi"]), combined.T)
                dbi = dit * sigmoid_derivative(np.dot(layer["Wi"], combined) + layer["bi"])
                dWo = np.dot(dot * sigmoid_derivative(np.dot(layer["Wo"], combined) + layer["bo"]), combined.T)
                dbo = dot * sigmoid_derivative(np.dot(layer["Wo"], combined) + layer["bo"])
                dWc = np.dot(dCt_tilde * tanh_derivative(np.dot(layer["Wc"], combined) + layer["bc"]), combined.T)
                dbc = dCt_tilde * tanh_derivative(np.dot(layer["Wc"], combined) + layer["bc"])

                # 添加 L2 正则化
                dWf += self.l2_reg * layer["Wf"]
                dWi += self.l2_reg * layer["Wi"]
                dWo += self.l2_reg * layer["Wo"]
                dWc += self.l2_reg * layer["Wc"]

                layer_grads[layer_idx]["Wf"] += dWf
                layer_grads[layer_idx]["bf"] += dbf
                layer_grads[layer_idx]["Wi"] += dWi
                layer_grads[layer_idx]["bi"] += dbi
                layer_grads[layer_idx]["Wo"] += dWo
                layer_grads[layer_idx]["bo"] += dbo
                layer_grads[layer_idx]["Wc"] += dWc
                layer_grads[layer_idx]["bc"] += dbc

                # 计算 dh_prev 和 dc_prev
                dcombined = (np.dot(layer["Wf"].T, dft * sigmoid_derivative(np.dot(layer["Wf"], combined) + layer["bf"])) +
                             np.dot(layer["Wi"].T, dit * sigmoid_derivative(np.dot(layer["Wi"], combined) + layer["bi"])) +
                             np.dot(layer["Wo"].T, dot * sigmoid_derivative(np.dot(layer["Wo"], combined) + layer["bo"])) +
                             np.dot(layer["Wc"].T, dCt_tilde * tanh_derivative(np.dot(layer["Wc"], combined) + layer["bc"])))
                dh_prev = dcombined[:self.hidden_size]
                dc_prev = ft * dc

                dh_next = dh_prev
                dc_next = dc_prev

        return layer_grads

    def update_weights(self, layer_grads, learning_rate):
        for i, layer in enumerate(self.layers):
            layer["Wf"] -= learning_rate * layer_grads[i]["Wf"]
            layer["bf"] -= learning_rate * layer_grads[i]["bf"]
            layer["Wi"] -= learning_rate * layer_grads[i]["Wi"]
            layer["bi"] -= learning_rate * layer_grads[i]["bi"]
            layer["Wo"] -= learning_rate * layer_grads[i]["Wo"]
            layer["bo"] -= learning_rate * layer_grads[i]["bo"]
            layer["Wc"] -= learning_rate * layer_grads[i]["Wc"]
            layer["bc"] -= learning_rate * layer_grads[i]["bc"]
            layer["Wh"] -= learning_rate * layer_grads[i]["Wh"]
            layer["bh"] -= learning_rate * layer_grads[i]["bh"]

# 数据归一化
def normalize_data(data):
    min_val = np.min(data)
    max_val = np.max(data)
    normalized_data = (data - min_val) / (max_val - min_val)
    return normalized_data, min_val, max_val

# 数据预处理
def preprocess_data(data, seq_length):
    inputs = []
    targets = []
    for i in range(len(data) - seq_length):
        inputs.append(data[i:i + seq_length])
        targets.append(data[i + seq_length])
    inputs = np.array(inputs)
    targets = np.array(targets)
    return inputs, targets

# 反归一化
def denormalize_data(data, min_val, max_val):
    return data * (max_val - min_val) + min_val

# 训练函数
def train_model(lstm, train_inputs, train_targets, epochs, learning_rate):
    for epoch in range(epochs):
        total_loss = 0
        for seq, target in zip(train_inputs, train_targets):
            outputs, all_h_lists, all_c_lists = lstm.forward(seq)
            target = target.reshape(-1, 1)
            loss = np.sum((outputs[-1] - target) ** 2)
            total_loss += loss
            layer_grads = lstm.backward(seq, target, all_h_lists, all_c_lists)
            lstm.update_weights(layer_grads, learning_rate)
        if epoch % 10 == 0:
            print(f'Epoch {epoch}, Loss: {total_loss / len(train_inputs)}')
    return lstm

# 测试函数
def test_model(lstm, test_inputs, test_targets, min_val, max_val):
    test_predictions = []
    for seq in test_inputs:
        output, _, _ = lstm.forward(seq)
        test_predictions.append(output[-1][0][0])

    # 结果反归一化
    test_predictions = denormalize_data(np.array(test_predictions), min_val, max_val)
    test_targets = denormalize_data(test_targets, min_val, max_val)

    # 计算RMSE
    test_rmse = np.sqrt(mean_squared_error(test_targets, test_predictions))
    print(f'Test RMSE: {test_rmse}')

    # 由于是回归问题，准确率和召回率不太适用，这里简单进行二分类转换
    binary_test_targets = (test_targets > np.median(test_targets)).astype(int)
    binary_test_predictions = (test_predictions > np.median(test_predictions)).astype(int)

    test_accuracy = accuracy_score(binary_test_targets, binary_test_predictions)
    test_recall = recall_score(binary_test_targets, binary_test_predictions)
    print(f'Test Accuracy: {test_accuracy}')
    print(f'Test Recall: {test_recall}')

    return test_predictions, test_targets

# 主函数
def main():
    # 数据文件路径
    data_path_train = 'zgpa_train.csv'
    df1 = pd.read_csv(data_path_train, parse_dates=['date'], index_col='date')
    data_path_test = 'zgpa_test.csv'
    df2 = pd.read_csv(data_path_test, parse_dates=['date'], index_col='date')

    # 假设这里根据日期索引的顺序生成一个序列作为要处理的数据
    data1 = np.arange(len(df1)).astype(float)
    data2 = np.arange(len(df2)).astype(float)

    seq_length = 10  # 时间步长（可根据数据长度调整）
    hidden_size = 50  # 增加LSTM层的单元数
    num_layers = 2  # 增加LSTM层的数量
    epochs = 100  # 增加训练轮数
    learning_rate = 0.001  # 调整学习率
    dropout_rate = 0.2  # Dropout率
    l2_reg = 0.01  # L2正则化系数

    # 数据处理流程
    # 数据归一化
    normalized_data, min_val, max_val = normalize_data(data1)
    # 划分输入序列和目标值
    inputs, targets = preprocess_data(normalized_data, seq_length)
    # 划分训练集和测试集（80%训练，20%测试）
    train_size = int(len(inputs) * 0.8)
    train_inputs, test_inputs = inputs[:train_size], inputs[train_size:]
    train_targets, test_targets = targets[:train_size], targets[train_size:]

    # LSTM 模型
    lstm = LSTM(input_size=1, hidden_size=hidden_size, num_layers=num_layers, dropout_rate=dropout_rate, l2_reg=l2_reg)

    # 训练模型
    lstm = train_model(lstm, train_inputs, train_targets, epochs, learning_rate)

    # 保存模型
    joblib.dump(lstm, 'lstm_model.pkl')

    # 测试模型
    test_predictions, test_targets = test_model(lstm, test_inputs, test_targets, min_val, max_val)

    # 可视化
    plt.figure(figsize=(12, 6))
    plt.plot(range(len(test_targets)), test_targets, label='Test Actual', color='green')
    plt.plot(range(len(test_targets)), test_predictions, label='Test Predicted', color='red', linestyle='--')
    plt.xlabel('Time Steps')
    plt.ylabel('Value')
    plt.title('Prediction with LSTM')
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()