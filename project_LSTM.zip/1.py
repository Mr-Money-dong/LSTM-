import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, accuracy_score, recall_score
import math
import talib
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from sympy.physics.control.control_plots import matplotlib

# 设置matplotlib支持中文
matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# 检查是否有可用的GPU
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'使用设备: {device}')

# 定义特征列
feature_columns = ['open', 'high', 'low', 'close', 'volume',
                   'MA5', 'MA10', 'MA20', 'RSI', 'MACD',
                   'MACD_SIGNAL', 'MACD_HIST', 'BB_UPPER',
                   'BB_MIDDLE', 'BB_LOWER', 'VOL_MA5',
                   'returns', 'volatility']


class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_layers=2, bidirectional=True):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional

        # 定义LSTM层
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            bidirectional=bidirectional,
            batch_first=True
        )

        # 计算全连接层的输入维度
        fc_input_size = hidden_size * 2 if bidirectional else hidden_size

        # 定义全连接层
        self.fc = nn.Linear(fc_input_size, output_size)

        # 初始化权重
        self.init_weights()

    def init_weights(self):
        for name, param in self.lstm.named_parameters():
            if 'weight' in name:
                nn.init.xavier_normal_(param)
            elif 'bias' in name:
                nn.init.zeros_(param)

        nn.init.xavier_normal_(self.fc.weight)
        nn.init.zeros_(self.fc.bias)

    def forward(self, x):
        # 初始化隐藏状态
        batch_size = x.size(0)
        h0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1),
                         batch_size,
                         self.hidden_size).to(device)
        c0 = torch.zeros(self.num_layers * (2 if self.bidirectional else 1),
                         batch_size,
                         self.hidden_size).to(device)

        # LSTM前向传播
        out, _ = self.lstm(x, (h0, c0))

        # 只使用最后一个时间步的输出
        out = self.fc(out[:, -1, :])

        return out


def calculate_technical_indicators(df):
    # 计算移动平均线
    df['MA5'] = talib.MA(df['close'], timeperiod=5)
    df['MA10'] = talib.MA(df['close'], timeperiod=10)
    df['MA20'] = talib.MA(df['close'], timeperiod=20)

    # 计算RSI
    df['RSI'] = talib.RSI(df['close'], timeperiod=14)

    # 计算MACD
    macd, signal, hist = talib.MACD(df['close'])
    df['MACD'] = macd
    df['MACD_SIGNAL'] = signal
    df['MACD_HIST'] = hist

    # 计算布林带
    upper, middle, lower = talib.BBANDS(df['close'])
    df['BB_UPPER'] = upper
    df['BB_MIDDLE'] = middle
    df['BB_LOWER'] = lower

    # 计算成交量指标
    df['VOL_MA5'] = talib.MA(df['volume'], timeperiod=5)

    return df


def preprocess_data(df):
    # 填充缺失值
    df = df.fillna(method='ffill')
    df = df.fillna(method='bfill')  # 如果前向填充后仍有缺失值，使用后向填充

    # 计算收益率
    df['returns'] = df['close'].pct_change()
    df['returns'] = df['returns'].fillna(0)  # 将第一个收益率设为0

    # 计算波动率
    df['volatility'] = df['returns'].rolling(window=20).std()
    df['volatility'] = df['volatility'].fillna(method='bfill')  # 填充前20个波动率值

    # 确保所有值都是有限的
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.fillna(method='ffill')
    df = df.fillna(method='bfill')

    return df


def load_data(train_file, test_file):
    # 读取数据
    train_data = pd.read_csv(train_file)
    test_data = pd.read_csv(test_file)

    # 计算技术指标
    train_data = calculate_technical_indicators(train_data)
    test_data = calculate_technical_indicators(test_data)

    # 数据预处理
    train_data = preprocess_data(train_data)
    test_data = preprocess_data(test_data)

    # 选择特征
    train_features = train_data[feature_columns].values
    test_features = test_data[feature_columns].values

    # 归一化
    scaler = MinMaxScaler()
    train_scaled = scaler.fit_transform(train_features)
    test_scaled = scaler.transform(test_features)

    # 确保没有nan值
    assert not np.isnan(train_scaled).any(), "训练数据中存在nan值"
    assert not np.isnan(test_scaled).any(), "测试数据中存在nan值"

    return train_scaled, test_scaled, scaler


def create_sequences(data, seq_length):
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:(i + seq_length)])
        y.append(data[i + seq_length, 3])  # 预测收盘价
    return np.array(X), np.array(y)


def train_model(model, train_loader, criterion, optimizer, num_epochs):
    model.train()
    for epoch in range(num_epochs):
        total_loss = 0
        for batch_X, batch_y in train_loader:
            # 将数据移到GPU
            batch_X = batch_X.to(device)
            batch_y = batch_y.to(device)

            # 前向传播
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()

            # 梯度裁剪，防止梯度爆炸
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

            optimizer.step()

            total_loss += loss.item()

        if (epoch + 1) % 10 == 0:
            print(f'轮次 [{epoch + 1}/{num_epochs}], 损失: {total_loss / len(train_loader):.4f}')

        # 检查损失是否为nan
        if np.isnan(total_loss):
            print("警告：检测到nan损失值，停止训练")
            break


def evaluate_model(model, test_loader, scaler):
    model.eval()
    predictions = []
    actuals = []

    with torch.no_grad():
        for batch_X, batch_y in test_loader:
            batch_X = batch_X.to(device)
            outputs = model(batch_X)

            predictions.extend(outputs.cpu().numpy())
            actuals.extend(batch_y.cpu().numpy())

    # 确保没有nan值
    predictions = np.array(predictions)
    actuals = np.array(actuals)

    if np.isnan(predictions).any() or np.isnan(actuals).any():
        print("警告：预测值或实际值中存在nan值")
        return None, None

    # 反归一化
    predictions = predictions.reshape(-1, 1)
    dummy = np.zeros((len(predictions), len(feature_columns)))
    dummy[:, 3] = predictions.flatten()
    predictions = scaler.inverse_transform(dummy)[:, 3]

    actuals = actuals.reshape(-1, 1)
    dummy = np.zeros((len(actuals), len(feature_columns)))
    dummy[:, 3] = actuals.flatten()
    actuals = scaler.inverse_transform(dummy)[:, 3]

    # 计算评估指标
    rmse = math.sqrt(mean_squared_error(actuals, predictions))

    # 计算方向准确率
    actual_direction = np.sign(np.diff(actuals))
    predicted_direction = np.sign(np.diff(predictions))
    direction_accuracy = accuracy_score(actual_direction, predicted_direction)

    # 计算召回率
    true_positives = np.sum((predicted_direction == 1) & (actual_direction == 1))
    false_negatives = np.sum((predicted_direction == -1) & (actual_direction == 1))
    recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0

    print(f'RMSE: {rmse:.4f}')
    print(f'方向准确率: {direction_accuracy:.4f}')
    print(f'召回率: {recall:.4f}')

    return predictions, actuals


def plot_results(predictions, actuals):
    plt.figure(figsize=(12, 6))
    plt.plot(actuals, label='实际价格')
    plt.plot(predictions, label='预测价格')
    plt.title('股票价格预测结果')
    plt.xlabel('时间')
    plt.ylabel('价格')
    plt.legend()
    plt.show()


def main():
    # 设置参数
    seq_length = 20
    hidden_size = 64
    input_size = len(feature_columns)
    output_size = 1
    num_epochs = 200
    batch_size = 32
    learning_rate = 0.001
    num_layers = 2

    # 加载数据
    train_data, test_data, scaler = load_data('zgpa_train.csv', 'zgpa_test.csv')

    # 创建序列
    X_train, y_train = create_sequences(train_data, seq_length)
    X_test, y_test = create_sequences(test_data, seq_length)

    # 转换为PyTorch张量
    X_train = torch.FloatTensor(X_train)
    y_train = torch.FloatTensor(y_train).reshape(-1, 1)
    X_test = torch.FloatTensor(X_test)
    y_test = torch.FloatTensor(y_test).reshape(-1, 1)

    # 创建数据加载器
    train_dataset = TensorDataset(X_train, y_train)
    test_dataset = TensorDataset(X_test, y_test)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    # 创建模型
    model = LSTMModel(input_size, hidden_size, output_size, num_layers=num_layers, bidirectional=True)
    model = model.to(device)

    # 定义损失函数和优化器
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # 训练模型
    print("开始训练模型...")
    train_model(model, train_loader, criterion, optimizer, num_epochs)

    # 评估模型
    print("\n开始评估模型...")
    predictions, actuals = evaluate_model(model, test_loader, scaler)

    if predictions is not None and actuals is not None:
        # 绘制结果
        plot_results(predictions, actuals)
    else:
        print("无法绘制结果，因为存在nan值")


if __name__ == "__main__":
    main()
